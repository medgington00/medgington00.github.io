advancement revoke @s only blockwords:interaction

execute if score #scoreboard whos_turn_is_it matches 0 if entity @s[team=!purple] run tellraw @s {"text":"Your team is not currently up!","color":"red"}
execute if score #scoreboard whos_turn_is_it matches 0 if entity @s[team=purple] run function blockwords:interaction_detection/on_interact_purple

execute if score #scoreboard whos_turn_is_it matches 1 if entity @s[team=!gold] run tellraw @s {"text":"Your team is not currently up!","color":"red"}
execute if score #scoreboard whos_turn_is_it matches 1 if entity @s[team=gold] run function blockwords:interaction_detection/on_interact_gold


execute as @e[type=interaction] run data remove entity @s interaction
execute as @e[type=interaction] run data remove entity @s attack