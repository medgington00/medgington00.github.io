data get storage blockwords:main blocks[0]
$data modify storage blockwords:main random_block set from storage blockwords:main blocks[$(block_index)]
$data remove storage blockwords:main blocks[$(block_index)]
function blockwords:game_setup/4_set_blocks with storage blockwords:main