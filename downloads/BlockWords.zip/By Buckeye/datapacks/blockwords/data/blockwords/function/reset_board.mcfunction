execute as @e[type=marker,tag=block_spot_marker] at @s run fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 white_concrete
execute as @e[type=marker,tag=block_spot_marker] at @s run setblock ~ ~ ~ air
kill @e[type=marker,tag=block_spot_marker]