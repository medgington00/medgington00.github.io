scoreboard players reset @s rejoin
tag @s add player_setup
tag @s remove spectating

tag @s add joining

execute if score @s game_seed = #scoreboard game_seed run function blockwords:player_setup/player_setup_existing
execute unless score @s game_seed = #scoreboard game_seed run function blockwords:player_setup/player_setup_new

tag @s remove joining