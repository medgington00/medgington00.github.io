scoreboard players reset @a bw.start

tag @a remove agent
tag @a remove player

tag @a[team=purple] add player
tag @a[team=gold] add player

execute store result score #scoreboard player_count_purple run execute if entity @a[team=purple]
execute store result score #scoreboard player_count_gold run execute if entity @a[team=gold]

execute if score #scoreboard player_count_purple matches 2.. if score #scoreboard player_count_gold matches 2.. run function blockwords:game_setup/0_post_check
execute if score #scoreboard player_count_purple matches ..1 run tellraw @a {"text":"You must have at least 2 players on each team to start the game!","color":"red"}
execute if score #scoreboard player_count_gold matches ..1 unless score #scoreboard player_count_purple matches ..1 run tellraw @a {"text":"You must have at least 2 players on each team to start the game!","color":"red"}