tag @s remove player
tag @s remove agent
tag @s remove spectating

tellraw @a [{"color":"dark_green","selector":"@s"}," has joined BlockWords!"]
execute if score #scoreboard whos_turn_is_it matches 0.. run tellraw @s {"text":"Game is currently in progress, you will be able to join next game","color":"gray"}
execute if score #scoreboard whos_turn_is_it matches 0.. run tag @s add spectating

execute unless score #scoreboard whos_turn_is_it matches 0.. run tp @s 30 56 0 90 0
execute unless score #scoreboard whos_turn_is_it matches 0.. run gamemode adventure @s