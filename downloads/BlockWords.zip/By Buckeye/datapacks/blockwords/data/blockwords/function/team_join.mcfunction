$tellraw @a [{"selector":"@s","color":"$(color)"},{"text":" has joined team $(team)!"}]
$team join $(team) @s