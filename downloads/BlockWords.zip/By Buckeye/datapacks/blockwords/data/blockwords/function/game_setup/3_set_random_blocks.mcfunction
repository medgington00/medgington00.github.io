execute store result score #scoreboard array_length run execute if data storage blockwords:main blocks[]

scoreboard players remove #scoreboard array_length 1
execute store result storage blockwords:main array_length int 1 run scoreboard players get #scoreboard array_length

function blockwords:game_setup/3_store_random_index with storage blockwords:main



# setblock ~ ~ ~ chest destroy
# loot insert ~ ~ ~ loot blockwords:random_block_list
# data modify storage blockwords:main random_block set from block ~ ~ ~ Items[0].id
# function blockwords:game_setup/3_set_random_blocks_call with storage blockwords:main