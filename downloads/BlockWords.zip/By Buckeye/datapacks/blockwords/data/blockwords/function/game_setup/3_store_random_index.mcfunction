$execute store result storage blockwords:main block_index int 1 run random value 0..$(array_length)
function blockwords:game_setup/3_macro_setup with storage blockwords:main