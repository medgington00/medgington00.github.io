#Returns the following values
# 0 -- correct
# 1 -- neutral
# 2 -- incorrect
# 3 -- skip
# 4 -- bomb

#Correct guesses
execute if entity @s[team=gold] if entity @e[type=interaction,tag=selected,tag=gold] run return 0
execute if entity @s[team=purple] if entity @e[type=interaction,tag=selected,tag=purple] run return 0

#Neutral guesses
execute if entity @e[type=interaction,tag=selected,tag=white] run return 1

#Incorrect guesses
execute if entity @s[team=purple] if entity @e[type=interaction,tag=selected,tag=gold] run return 2
execute if entity @s[team=gold] if entity @e[type=interaction,tag=selected,tag=purple] run return 2

#Skip guesses
execute if entity @e[type=interaction,tag=selected,tag=gray] run return 3

#Bomb guesses
execute if entity @e[type=interaction,tag=selected,tag=red] run return 4