#Team setup
team add gold "Gold"
team modify gold color gold
team add purple "Purple"
team modify purple color light_purple
team modify gold friendlyFire false
team modify purple friendlyFire false

team modify gold collisionRule never
team modify purple collisionRule never

gamerule sendCommandFeedback false
gamerule commandBlockOutput false
gamerule randomTickSpeed 0
difficulty peaceful

#block array
scoreboard objectives add array_length dummy

#scoreboard
scoreboard objectives add blocks_left dummy
scoreboard objectives modify blocks_left displayautoupdate true
scoreboard objectives modify blocks_left numberformat styled {"color":"white"}
scoreboard objectives modify blocks_left displayname {"text":"Blocks Left","color":"dark_green","bold":true,"underlined":true}

scoreboard objectives add player_count_purple dummy
scoreboard objectives add player_count_gold dummy

scoreboard objectives add is_guess_correct dummy

# 0 purple -- 1 gold
scoreboard objectives add whos_turn_is_it dummy

#triggers
scoreboard objectives add bw.start trigger
scoreboard objectives add bw.end trigger

#rejoin detection
scoreboard objectives add rejoin minecraft.custom:minecraft.leave_game
scoreboard objectives add game_seed dummy

#unbreakable paintings
execute as @e[type=painting] run data modify entity @s Invulnerable set value 1b