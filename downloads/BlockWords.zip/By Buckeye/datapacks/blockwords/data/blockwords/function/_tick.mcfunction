#agent particles
execute at @e[tag=block_spot_marker,tag=gold] run particle wax_on ~1.5 ~ ~ 0 0 .75 0 3 force @a[tag=agent]
execute at @e[tag=block_spot_marker,tag=gold] run particle wax_on ~-1.5 ~ ~ 0 0 .75 0 3 force @a[tag=agent]
execute at @e[tag=block_spot_marker,tag=gold] run particle wax_on ~ ~ ~1.5 .75 0 0 0 3 force @a[tag=agent]
execute at @e[tag=block_spot_marker,tag=gold] run particle wax_on ~ ~ ~-1.5 .75 0 0 0 3 force @a[tag=agent]

execute at @e[tag=block_spot_marker,tag=purple] run particle dust{color:[1.000,0.333,1.000],scale:1} ~1.5 ~ ~ 0 0 .75 0 3 force @a[tag=agent]
execute at @e[tag=block_spot_marker,tag=purple] run particle dust{color:[1.000,0.333,1.000],scale:1} ~-1.5 ~ ~ 0 0 .75 0 3 force @a[tag=agent]
execute at @e[tag=block_spot_marker,tag=purple] run particle dust{color:[1.000,0.333,1.000],scale:1} ~ ~ ~1.5 .75 0 0 0 3 force @a[tag=agent]
execute at @e[tag=block_spot_marker,tag=purple] run particle dust{color:[1.000,0.333,1.000],scale:1} ~ ~ ~-1.5 .75 0 0 0 3 force @a[tag=agent]

execute at @e[tag=block_spot_marker,tag=red] run particle raid_omen ~ ~ ~ .5 0 .5 0 6 force @a[tag=agent]

#display current turn
execute if score #scoreboard whos_turn_is_it matches 0 run title @a actionbar {"text":"Purple Team's Turn","color":"dark_purple"}
execute if score #scoreboard whos_turn_is_it matches 1 run title @a actionbar {"text":"Gold Team's Turn","color":"gold"}

#triggers
scoreboard players enable @a bw.start
execute as @a if score @s bw.start matches 1.. run function blockwords:game_setup/_start_game
scoreboard players enable @a bw.end
execute as @a if score @s bw.end matches 1.. run function blockwords:game_setup/end_game

#player setup upon joining
execute as @a[tag=!player_setup] at @s run function blockwords:player_setup/player_setup
execute as @a[scores={rejoin=1..}] at @s run function blockwords:player_setup/player_setup

#handle tags for spectators
execute as @a[tag=spectating,gamemode=!spectator] run gamemode spectator
execute as @a[tag=spectating,gamemode=!spectator,tag=!agent] run tag @s add agent

#team select
execute unless score #scoreboard whos_turn_is_it matches 0.. as @a[team=!purple] at @s if block ~ ~-.5 ~ purple_concrete run function blockwords:team_join {team:"purple",color:"dark_purple"}
execute unless score #scoreboard whos_turn_is_it matches 0.. as @a[team=!gold] at @s if block ~ ~-.5 ~ yellow_concrete run function blockwords:team_join {team:"gold",color:"gold"}

#used for skip turn interaction
execute as @e[type=glow_item_frame] at @s unless entity @e[type=interaction,distance=..1] run summon interaction ~ ~-.25 ~ {width:1.25f,height:1.25f,Tags:["block_spot_int","gray"]}

#tp all agents and spectators to a birds eye view
tp @a[gamemode=spectator,name=!Buckeye] 12 66 0

effect give @a resistance 2 10 true