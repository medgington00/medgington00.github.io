#kill old markers and interactions incase they still exist
kill @e[type=marker,tag=block_spot_marker]
kill @e[type=interaction,tag=block_spot_int]

#summon new markers in a 5x5 grid
summon marker ~-8 ~ ~-8 {Tags:["block_spot_marker"]}
summon marker ~-4 ~ ~-8 {Tags:["block_spot_marker"]}
summon marker ~ ~ ~-8 {Tags:["block_spot_marker"]}
summon marker ~4 ~ ~-8 {Tags:["block_spot_marker"]}
summon marker 8 ~ ~-8 {Tags:["block_spot_marker"]}

summon marker ~-8 ~ ~-4 {Tags:["block_spot_marker"]}
summon marker ~-4 ~ ~-4 {Tags:["block_spot_marker"]}
summon marker ~ ~ ~-4 {Tags:["block_spot_marker"]}
summon marker ~4 ~ ~-4 {Tags:["block_spot_marker"]}
summon marker 8 ~ ~-4 {Tags:["block_spot_marker"]}

summon marker ~-8 ~ ~ {Tags:["block_spot_marker"]}
summon marker ~-4 ~ ~ {Tags:["block_spot_marker"]}
summon marker ~ ~ ~ {Tags:["block_spot_marker"]}
summon marker ~4 ~ ~ {Tags:["block_spot_marker"]}
summon marker 8 ~ ~ {Tags:["block_spot_marker"]}

summon marker ~-8 ~ ~4 {Tags:["block_spot_marker"]}
summon marker ~-4 ~ ~4 {Tags:["block_spot_marker"]}
summon marker ~ ~ ~4 {Tags:["block_spot_marker"]}
summon marker ~4 ~ ~4 {Tags:["block_spot_marker"]}
summon marker 8 ~ ~4 {Tags:["block_spot_marker"]}

summon marker ~-8 ~ 8 {Tags:["block_spot_marker"]}
summon marker ~-4 ~ 8 {Tags:["block_spot_marker"]}
summon marker ~ ~ 8 {Tags:["block_spot_marker"]}
summon marker ~4 ~ 8 {Tags:["block_spot_marker"]}
summon marker 8 ~ 8 {Tags:["block_spot_marker"]}

#for each marker set a random block (with removal)
execute as @e[type=marker,tag=block_spot_marker] at @s run function blockwords:game_setup/3_set_random_blocks

#set team for each block as well as a BOMB block (9 purple 8 gold)
tag @e[type=marker,tag=block_spot_marker,limit=9,sort=random] add purple
tag @e[type=marker,tag=block_spot_marker,limit=8,sort=random,tag=!purple] add gold
tag @e[type=marker,tag=block_spot_marker,limit=1,sort=random,tag=!gold,tag=!purple] add red
tag @e[type=marker,tag=block_spot_marker,tag=!gold,tag=!purple,tag=!red] add white

#fill white under blocks
execute as @e[type=marker,tag=block_spot_marker] at @s run fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 white_concrete

#summon interactions on each block based on team
execute as @e[type=marker,tag=purple,tag=block_spot_marker] at @s run summon interaction ~ ~-.125 ~ {width:1.25f,height:1.25f,Tags:["purple","block_spot_int"]}
execute as @e[type=marker,tag=gold,tag=block_spot_marker] at @s run summon interaction ~ ~-.125 ~ {width:1.25f,height:1.25f,Tags:["gold","block_spot_int"]}
execute as @e[type=marker,tag=white,tag=block_spot_marker] at @s run summon interaction ~ ~-.125 ~ {width:1.25f,height:1.25f,Tags:["white","block_spot_int"]}
execute as @e[type=marker,tag=red,tag=block_spot_marker] at @s run summon interaction ~ ~-.125 ~ {width:1.25f,height:1.25f,Tags:["red","block_spot_int"]}