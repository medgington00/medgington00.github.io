execute as @e[type=interaction] if data entity @s attack run tag @s add selected
execute as @e[type=interaction] if data entity @s interaction run tag @s add selected

execute as @e[type=interaction,tag=selected] run data remove entity @s attack
execute as @e[type=interaction,tag=selected] run data remove entity @s interaction

execute store result score #scoreboard is_guess_correct as @s run function blockwords:interaction_detection/check_guess

#If guess is correct
execute if score #scoreboard is_guess_correct matches 0 run tellraw @a [{"selector":"@s","color":"green"},{"text":" guessed correctly, point for purple!"}]
execute if score #scoreboard is_guess_correct matches 0 at @e[type=interaction,tag=block_spot_int,tag=selected] run particle egg_crack ~ ~1.5 ~ .5 .25 .5 .1 32 normal @a
execute if score #scoreboard is_guess_correct matches 0 run playsound block.note_block.chime player @a ~ ~ ~ 3 1

#If guess is neutral
execute if score #scoreboard is_guess_correct matches 1 run tellraw @a [{"selector":"@s","color":"gray"},{"text":" guessed a neutral spot. gold team is up!"}]
execute if score #scoreboard is_guess_correct matches 1 run playsound block.note_block.banjo player @a ~ ~ ~ 3 1

#If guess is incorrect
execute if score #scoreboard is_guess_correct matches 2 run tellraw @a [{"selector":"@s","color":"red"},{"text":" picked for the wrong team. gold team is up!"}]
execute if score #scoreboard is_guess_correct matches 2 at @e[type=interaction,tag=block_spot_int,tag=selected] run particle angry_villager ~ ~1 ~ .5 .25 .5 .1 6 normal @a
execute if score #scoreboard is_guess_correct matches 2 run playsound entity.warden.death player @a ~ ~ ~ 3 1

#If guess is skipped
execute if score #scoreboard is_guess_correct matches 3 run tellraw @a [{"selector":"@s","color":"white"},{"text":" passed on their turn. gold team is up!"}]

#If guess if bomb
execute if score #scoreboard is_guess_correct matches 4 run tellraw @a [{"selector":"@s","color":"dark_red"},{"text":" chose the bomb, gold team wins!"}]
execute if score #scoreboard is_guess_correct matches 4 at @e[type=interaction,tag=block_spot_int,tag=selected] run particle explosion ~ ~1 ~ .25 .25 .25 0 10 normal @a
execute if score #scoreboard is_guess_correct matches 4 run playsound entity.ender_dragon.growl player @a ~ ~ ~ 3 1
execute if score #scoreboard is_guess_correct matches 4 run playsound entity.generic.explode player @a ~ ~ ~ 3 .75

execute if score #scoreboard is_guess_correct matches 1..3 run scoreboard players set #scoreboard whos_turn_is_it 0

#Setblocks
execute as @e[type=interaction,tag=gold,tag=selected] at @s run fill ~-1 ~ ~-1 ~1 ~ ~1 yellow_concrete
execute if entity @e[type=interaction,tag=gold,tag=selected] run scoreboard players remove Gold: blocks_left 1

execute as @e[type=interaction,tag=purple,tag=selected] at @s run fill ~-1 ~ ~-1 ~1 ~ ~1 purple_concrete
execute if entity @e[type=interaction,tag=purple,tag=selected] run scoreboard players remove Purple: blocks_left 1

execute as @e[type=interaction,tag=white,tag=selected] at @s run fill ~-1 ~ ~-1 ~1 ~ ~1 gray_concrete

execute as @e[type=interaction,tag=red,tag=selected] at @s run fill ~-1 ~ ~-1 ~1 ~ ~1 red_concrete
execute if entity @e[type=interaction,tag=red,tag=selected] run scoreboard players set Gold: blocks_left 0

function blockwords:check_winner

kill @e[tag=selected,type=interaction,tag=block_spot_int]
