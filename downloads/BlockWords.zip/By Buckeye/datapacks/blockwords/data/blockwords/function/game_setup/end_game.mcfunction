fill 15 56 1 15 58 -1 air

scoreboard players reset @a bw.end

kill @e[type=interaction,tag=block_spot_int]
tag @a add agent

scoreboard players set #scoreboard whos_turn_is_it -1

gamemode adventure @a

scoreboard objectives setdisplay sidebar

playsound item.goat_horn.sound.0 master @a 0 70 0 32 .75
execute if score Purple: blocks_left matches ..0 run function blockwords:game_setup/play_win_effects_purple
execute if score Gold: blocks_left matches ..0 run function blockwords:game_setup/play_win_effects_gold