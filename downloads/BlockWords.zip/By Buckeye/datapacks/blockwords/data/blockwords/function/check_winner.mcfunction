execute if score Purple: blocks_left matches ..0 run tellraw @a {"text":"Game over, purple team wins!","color":"dark_purple"}
execute if score Gold: blocks_left matches ..0 run tellraw @a {"text":"Game over, gold team wins!","color":"gold"}

execute if score Purple: blocks_left matches ..0 run function blockwords:game_setup/end_game
execute if score Gold: blocks_left matches ..0 run function blockwords:game_setup/end_game