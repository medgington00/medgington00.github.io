#run end game to clean up all tags and scores
# function blockwords:game_setup/end_game

#block off lobby
fill 15 56 1 15 58 -1 minecraft:tinted_glass

#clear tags
tag @a remove player
tag @a remove agent
tag @a remove spectating

#join everyone to purple if they dont have a team
execute as @a[team=!purple,team=!gold] run team join purple @s
#set random game seed to handle rejoining players
# The game seed will detect if the joining player matches the current game or joined from
# a former game. This allows players to leave mid game without being kicked out
# of the game upon rejoining
execute store result score #scoreboard game_seed run random value -99999..99999
execute store result score @a game_seed run scoreboard players get #scoreboard game_seed

#update value to start with purple's turn
scoreboard players set #scoreboard whos_turn_is_it 0

#choose one agent on each team and tellraw to let it be known
tag @r[team=purple,limit=1] add agent
tag @r[team=gold,limit=1] add agent
tellraw @a [{"color":"dark_purple","selector":"@a[team=purple,tag=agent]"},{"color":"white","text":" and "},{"color":"gold","selector":"@a[team=gold,tag=agent]"},{"color":"white","text":" have been selected as Agents!"}]

#agent setup/initial tp
gamemode spectator @a[tag=agent]
tp @a[tag=!agent] 0 62 0
tp @a[tag=agent] 12 66 0 90 0

#setup scoreb oard displays and fake players
scoreboard objectives setdisplay sidebar blocks_left
team join purple Purple:
team join gold Gold:
scoreboard players set Purple: blocks_left 9
scoreboard players set Gold: blocks_left 8


#cont.
execute positioned 0 56 0 run function blockwords:game_setup/1_load_blocks_to_storage

